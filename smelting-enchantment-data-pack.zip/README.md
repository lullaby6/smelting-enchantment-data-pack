# Smelting Enchantment Data-Pack

This datapack adds a new enchantment for the pickaxes, the “Smelting” enchantment, this new enchantment allows you to mine ores and have them drop the ingot instead of the raw ore.

### Disable

```
/datapack disable smelting_enchantment
```

### Enable

```
/datapack enable smelting_enchantment
```